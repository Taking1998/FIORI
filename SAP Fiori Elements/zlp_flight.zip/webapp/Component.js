jQuery.sap.declare("zlp_flight.Component");
sap.ui.getCore().loadLibrary("sap.ui.generic.app");
jQuery.sap.require("sap.ui.generic.app.AppComponent");

sap.ui.generic.app.AppComponent.extend("zlp_flight.Component", {
	metadata: {
		"manifest": "json"
	}
});